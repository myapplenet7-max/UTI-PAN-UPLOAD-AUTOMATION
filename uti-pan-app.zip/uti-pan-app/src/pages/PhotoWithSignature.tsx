import { useState } from 'react'
import UploadZone from '../components/UploadZone'
import { downloadDataUrl } from '../lib/utils'

export default function PhotoWithSignature({ apiKey }: { apiKey: string }) {
  const [photo, setPhoto] = useState<File | null>(null)
  const [sig, setSig] = useState<File | null>(null)
  const [result, setResult] = useState<string | null>(null)
  const [status, setStatus] = useState<'idle' | 'processing' | 'done' | 'error'>('idle')
  const [msg, setMsg] = useState('')
  const [sigScale, setSigScale] = useState(30)
  const [sigPos, setSigPos] = useState({ x: 50, y: 80 })

  const combine = async () => {
    if (!photo || !sig) return
    setStatus('processing'); setMsg('Combining photo and signature...')
    try {
      const photoImg = await loadImg(photo)
      const sigImg = await loadImg(sig)

      const canvas = document.createElement('canvas')
      canvas.width = 413; canvas.height = 531
      const ctx = canvas.getContext('2d')!

      // White background
      ctx.fillStyle = '#ffffff'
      ctx.fillRect(0, 0, 413, 531)

      // Draw photo
      ctx.drawImage(photoImg, 0, 0, 413, 531)

      // Draw signature overlay
      const sigW = Math.round(413 * sigScale / 100)
      const sigH = Math.round(sigW * sigImg.height / sigImg.width)
      const sigX = Math.round((413 - sigW) * sigPos.x / 100)
      const sigY = Math.round((531 - sigH) * sigPos.y / 100)

      ctx.globalAlpha = 0.9
      ctx.drawImage(sigImg, sigX, sigY, sigW, sigH)
      ctx.globalAlpha = 1

      const dataUrl = canvas.toDataURL('image/jpeg', 0.92)
      setResult(dataUrl)
      setStatus('done')
      setMsg('✓ Photo with signature created')
    } catch (e: any) {
      setStatus('error')
      setMsg('Error: ' + e.message)
    }
  }

  const loadImg = (file: File): Promise<HTMLImageElement> =>
    new Promise((resolve, reject) => {
      const img = new Image()
      img.onload = () => resolve(img)
      img.onerror = reject
      img.src = URL.createObjectURL(file)
    })

  return (
    <div className="page">
      <div className="page-header">
        <h2>🪪 Photo + Signature Creator</h2>
        <p>Combine extracted photo and signature into a single image for UTI PAN applications.</p>
        <div className="badge-row">
          {['Auto Overlay', 'Position Control', 'Size Control', 'UTI Format'].map(b => (
            <span className="badge" key={b}>{b}</span>
          ))}
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        <div className="card">
          <div className="card-title">Step 1: Upload Photo</div>
          <UploadZone file={photo} onFile={setPhoto} label="Upload face photo" />
        </div>
        <div className="card">
          <div className="card-title">Step 2: Upload Signature</div>
          <UploadZone file={sig} onFile={setSig} label="Upload signature image" />
        </div>
      </div>

      <div className="card">
        <div className="card-title">Signature Settings</div>
        <div className="form-row">
          <div className="form-group">
            <label className="form-label">Signature Size: {sigScale}% of photo width</label>
            <input type="range" min="10" max="80" value={sigScale}
              onChange={e => setSigScale(+e.target.value)}
              style={{ width: '100%', accentColor: 'var(--accent)' }} />
          </div>
          <div className="form-group">
            <label className="form-label">Vertical Position: {sigPos.y}% from top</label>
            <input type="range" min="0" max="100" value={sigPos.y}
              onChange={e => setSigPos(p => ({ ...p, y: +e.target.value }))}
              style={{ width: '100%', accentColor: 'var(--accent)' }} />
          </div>
        </div>
        <button className="btn btn-primary" onClick={combine} disabled={!photo || !sig || status === 'processing'}>
          {status === 'processing' ? <><span className="spinner" /> Processing...</> : '🪪 Create Combined Image'}
        </button>
      </div>

      {status !== 'idle' && (
        <div className={`status ${status === 'processing' ? 'loading' : status === 'done' ? 'success' : 'error'}`}>
          {status === 'processing' && <span className="spinner" />}
          {msg}
        </div>
      )}

      {result && (
        <div className="card">
          <div className="card-title">Result</div>
          <img src={result} style={{ maxWidth: 300, borderRadius: 8, marginBottom: 16, border: '1px solid var(--border)' }} />
          <div style={{ display: 'flex', gap: 10 }}>
            <button className="btn btn-primary" onClick={() => downloadDataUrl(result, 'photo-with-signature.jpg')}>
              ⬇️ Download JPG
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
